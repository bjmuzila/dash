'use strict';
/**
 * server-v2/household-routes.cjs — every /api/hh/* route for budget.cbedge.net.
 *
 * Kept OUT of api-router.js on purpose: that file is already 8k lines, and the
 * household app is a separate product with a separate auth system. api-router
 * touches this in exactly two places:
 *   1. an `auth: 'household'` branch in enforceAuth()
 *   2. one require + one call, right before the dispatcher
 *
 * Routes:
 *   POST /api/hh/auth/login            public     — sets hh_session
 *   POST /api/hh/auth/logout           public     — clears it
 *   GET  /api/hh/auth/me               public     — 200 {user} or 401, no redirect
 *   POST /api/hh/auth/change-password  household
 *   GET  /api/hh/auth/pin-status       public     — should the login screen draw
 *        the PIN pad? Answered from the hh_device cookie, so a stranger with no
 *        cookie always gets { hasPin:false } and the plain password form.
 *   POST /api/hh/auth/pin-login        public     — { pin } → sets hh_session
 *   GET  /api/hh/auth/pin              household  — is this browser armed, and
 *                                                   how many others are
 *   POST /api/hh/auth/pin              household  — { pin } → sets hh_device
 *   POST /api/hh/auth/pin/remove       household  — { allDevices? } → forget
 *   GET  /api/hh/health                public     — deploy smoke test
 *   GET  /api/hh/today                 household  — the composed Today payload
 *   GET  /api/hh/tasks                 household  — ?scope=open|done|done-all|all
 *        'done' returns only the last 5 days; 'done-all' is the full history.
 *   POST /api/hh/tasks                 household  — action dispatch
 *   GET  /api/hh/notes                 household
 *   POST /api/hh/notes                 household  — action dispatch
 *   GET  /api/hh/settings              household
 *   POST /api/hh/settings              household
 *   GET  /api/hh/recipes               household  — ?id=N one recipe, else the index
 *   POST /api/hh/recipes               household  — action dispatch (recipe.cbedge.net)
 *   GET  /api/hh/recipes/week          household  — what's planned, by day
 *   POST /api/hh/recipes/week          household  — unplan / move a planned meal
 *   POST /api/hh/recipes/bulk          household  — start/cancel a bulk URL import
 *   GET  /api/hh/recipes/bulk          household  — bulk import progress
 *   GET  /api/hh/recipes/image         household  — recipe photo bytes (?id=N&v=etag)
 *   POST /api/hh/recipes/image         household  — replace/remove a recipe photo
 *
 * There is deliberately NO signup route. Accounts are created with
 * server-v2/scripts/hh-user.js. Two people, forever.
 *
 * ── THE VISIBILITY RULE ────────────────────────────────────────────────────
 * Every household row carries owner_id + visibility, and since 2026-08 every
 * row is 'shared' — see the migration in _lib-household.cjs. Both people can
 * see AND edit everything; a shared list only one person can change is useless,
 * and a private one nobody remembered to share is worse.
 *
 *   read : owner_id = :me OR visibility = 'shared'
 *   write: owner_id = :me OR visibility = 'shared'
 *
 * That predicate is now always true, but it is defined ONCE below as VISIBLE
 * and still reused by every query. Do not hand-roll it per route and do not
 * delete it: it is the safety net if a row ever ends up private again, and it
 * is what makes reverting the policy a one-line change.
 */

const hh = require('./_lib-household.cjs');
// Optional by design: without Google config this loads fine, reports
// configured:false, and the calendar card says "not set up" instead of
// offering a Connect button that would dead-end at Google.
let gcal = null;
try { gcal = require('./_lib-google-calendar.cjs'); }
catch (e) { console.warn('[household] google-calendar lib not loaded:', e.message); }
// Subscribed ICS/webcal feeds. A separate source from Google on purpose: a team
// or school feed read directly is current within 30 minutes, where the same
// feed subscribed inside Google updates on Google's schedule, which can be a
// day. Also optional — without it the calendar is simply Google-only.
let icsFeeds = null;
try { icsFeeds = require('./_lib-ics-feeds.cjs'); }
catch (e) { console.warn('[household] ics-feeds lib not loaded:', e.message); }
// The budget, read from the SAME tables /owner/budget uses. Optional like the
// rest: without the DB bundle the routes simply don't register.
let hbudget = null;
try { hbudget = require('./_lib-household-budget.cjs'); }
catch (e) { console.warn('[household] budget lib not loaded:', e.message); }
let hroutines = null;
try { hroutines = require('./_lib-household-routines.cjs'); }
catch (e) { console.warn('[household] routines lib not loaded:', e.message); }
let hprojects = null;
try { hprojects = require('./_lib-household-projects.cjs'); }
catch (e) { console.warn('[household] projects lib not loaded:', e.message); }
let hlists = null;
try { hlists = require('./_lib-household-lists.cjs'); }
catch (e) { console.warn('[household] lists lib not loaded:', e.message); }
// The cookbook behind recipe.cbedge.net. Optional like the rest — without the
// DB bundle the /api/hh/recipes routes simply don't register and the recipe SPA
// shows its empty state instead of the dashboard failing to boot.
let hrecipes = null;
try { hrecipes = require('./_lib-household-recipes.cjs'); }
catch (e) { console.warn('[household] recipes lib not loaded:', e.message); }

// THE access predicate. $1 is always the caller's hh_users.id.
const VISIBLE = `(owner_id = $1 OR visibility = 'shared')`;

// due_date is cast to TEXT deliberately. It is a Postgres DATE — a calendar
// day, not an instant — but `pg` hydrates it into a JS Date at UTC midnight,
// which JSON-serialises to "2026-08-10T00:00:00.000Z". Any client east or west
// of UTC then renders the wrong day: in Eastern that is 8pm on Aug 9, so every
// due date would display one day early and "due today" would look overdue.
// Sending 'YYYY-MM-DD' kills the entire class of bug at the source, and it is
// the same shape an <input type="date"> expects. Do not "simplify" this back.
const TASK_COLS = `id, owner_id, visibility, title, notes,
  to_char(due_date, 'YYYY-MM-DD') AS due_date, starred,
  project, project_id, urgent, done_at, created_at, updated_at, touched_at`;

function registerHouseholdRoutes({ register, send, readJson }) {
  if (!hh.available()) {
    console.warn('[household] no DB layer — /api/hh/* not registered');
    return 0;
  }

  const NO_STORE = 'no-store, must-revalidate';
  const nostore = { 'Cache-Control': NO_STORE };
  let n = 0;
  const add = (path, def) => { register(path, def); n++; };

  // Accepts one cookie or several — PIN sign-in sets hh_session AND re-issues
  // hh_device in the same response. Node's setHeader takes an array for that.
  const authHeaders = (cookie) => {
    const list = (Array.isArray(cookie) ? cookie : [cookie]).filter(Boolean);
    if (!list.length) return nostore;
    return { ...nostore, 'Set-Cookie': list.length === 1 ? list[0] : list };
  };

  const publicUser = (u, extra = {}) => ({
    id: u.id,
    email: u.email,
    displayName: u.display_name,
    budgetProfileKey: u.budget_profile_key,
    tz: u.tz,
    mustChangePassword: !!u.must_change_password,
    // Whether THIS browser is armed for quick sign-in. On the user object
    // rather than a separate call because the SPA needs it on every load to
    // decide whether to offer PIN setup, and /me is already that round-trip.
    pinOnThisDevice: false,
    ...extra,
  });

  // Dates are compared in the user's timezone, not UTC. Without this a task due
  // "today" flips to overdue at 8pm ET, when UTC rolls over.
  const todayIn = (tz) => {
    const p = new Intl.DateTimeFormat('en-US', {
      timeZone: tz || 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit',
    }).formatToParts(new Date());
    const m = {};
    p.forEach((x) => { m[x.type] = x.value; });
    return `${m.year}-${m.month}-${m.day}`;
  };

  const str = (v, max = 2000) => String(v ?? '').trim().slice(0, max);
  // EVERYTHING IS SHARED. This app has two users who live together; a task only
  // one of them can see is the failure mode it exists to prevent, and the
  // private/shared switch was a decision nobody wanted to make at capture time.
  // Kept as a function rather than deleted so the callers below still read as
  // "whatever visibility this row gets" — and so flipping the policy back is
  // one line, not a sweep. See the migration in _lib-household.cjs.
  const vis = () => 'shared';
  // A date input arrives as 'YYYY-MM-DD' or empty. Anything else is dropped
  // rather than passed to Postgres, so a malformed value can't throw a 500.
  const dateOrNull = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(String(v ?? '')) ? String(v) : null);

  // ═══════════════════════════════════════════════════════════════════════════
  // Auth
  // ═══════════════════════════════════════════════════════════════════════════

  add('/api/hh/auth/login', {
    auth: 'public', methods: ['POST'],
    async handler(req, res) {
      try {
        const body = await readJson(req, 8192);
        const result = await hh.login({ email: body?.email, password: body?.password, req });
        if (!result.ok) { send(res, result.code, { error: result.error }, nostore); return; }
        const pinOnThisDevice = await hh.deviceHasPin(req, result.user.id);
        send(res, 200, { ok: true, user: publicUser(result.user, { pinOnThisDevice }) },
             authHeaders(result.cookie));
      } catch (err) { send(res, 500, { error: String(err?.message || err) }, nostore); }
    },
  });

  // Public so a stale/invalid cookie can still be cleared instead of 401ing
  // into a state where you can't sign out.
  add('/api/hh/auth/logout', {
    auth: 'public', methods: ['POST'],
    async handler(req, res) {
      try { await hh.destroySession(req); } catch { /* clear the cookie regardless */ }
      send(res, 200, { ok: true }, authHeaders(hh.clearCookie()));
    },
  });

  // Public + 401 rather than auth:'household', so a signed-out visitor gets
  // clean JSON the SPA can render a login form for — no redirect, no HTML.
  add('/api/hh/auth/me', {
    auth: 'public', methods: ['GET'],
    async handler(req, res) {
      const u = await hh.userFromRequest(req);
      if (!u) { send(res, 401, { error: 'no-session' }, nostore); return; }
      let cookie = null;
      if (hh.shouldSlide(u)) {
        try {
          const r = await hh.refreshSession(req);
          if (r) cookie = hh.sessionCookie(r.token, hh.SESSION_DAYS * 24 * 60 * 60);
        } catch { /* keep the existing cookie */ }
      }
      const pinOnThisDevice = await hh.deviceHasPin(req, u.id);
      send(res, 200, { user: publicUser(u, { pinOnThisDevice }) }, authHeaders(cookie));
    },
  });

  add('/api/hh/auth/change-password', {
    auth: 'household', methods: ['POST'],
    async handler(req, res, _ctx, access) {
      try {
        const body = await readJson(req, 8192);
        const result = await hh.changePassword({
          userId: access.hhUser.id,
          currentPassword: body?.currentPassword,
          newPassword: body?.newPassword,
          req,
        });
        if (!result.ok) { send(res, result.code, { error: result.error }, nostore); return; }
        send(res, 200, { ok: true }, authHeaders(result.cookie));
      } catch (err) { send(res, 500, { error: String(err?.message || err) }, nostore); }
    },
  });

  // ── Quick sign-in ──────────────────────────────────────────────────────
  // See the PIN section of _lib-household.cjs for why a 4-digit secret is safe
  // here: it only works alongside the hh_device cookie, and five wrong guesses
  // forget the device outright.

  // Public: the whole point is answering this while signed OUT. With no
  // hh_device cookie it returns { hasPin:false } and the SPA draws the ordinary
  // password form — a stranger learns nothing about who uses this app.
  add('/api/hh/auth/pin-status', {
    auth: 'public', methods: ['GET'],
    async handler(req, res) {
      try { send(res, 200, await hh.pinStatus(req), nostore); }
      catch { send(res, 200, { hasPin: false }, nostore); }
    },
  });

  add('/api/hh/auth/pin-login', {
    auth: 'public', methods: ['POST'],
    async handler(req, res) {
      try {
        const body = await readJson(req, 4096);
        const result = await hh.pinLogin({ pin: body?.pin, req });
        if (!result.ok) {
          // `forget` means the device row is gone. Clear the cookie with it, so
          // the next load asks for a password instead of a PIN that can no
          // longer be right.
          send(res, result.code,
               { error: result.error, forget: !!result.forget, attemptsLeft: result.attemptsLeft ?? null },
               result.forget ? authHeaders(hh.clearDeviceCookie()) : nostore);
          return;
        }
        send(res, 200, { ok: true, user: publicUser(result.user, { pinOnThisDevice: true }) },
             authHeaders([result.cookie, result.deviceCookie]));
      } catch (err) { send(res, 500, { error: String(err?.message || err) }, nostore); }
    },
  });

  // Arming a PIN requires a live session — a PIN is a shortcut back to access
  // you already proved with a password, never a way to create it.
  add('/api/hh/auth/pin', {
    auth: 'household', methods: ['GET', 'POST'],
    async handler(req, res, _ctx, access) {
      try {
        if (req.method === 'GET') {
          send(res, 200, {
            hasPinOnThisDevice: await hh.deviceHasPin(req, access.hhUser.id),
            devices: await hh.countPinDevices(access.hhUser.id),
          }, nostore);
          return;
        }
        const body = await readJson(req, 4096);
        const result = await hh.setPin({ userId: access.hhUser.id, pin: body?.pin, req });
        if (!result.ok) { send(res, result.code, { error: result.error }, nostore); return; }
        send(res, 200, { ok: true }, authHeaders(result.cookie));
      } catch (err) { send(res, 500, { error: String(err?.message || err) }, nostore); }
    },
  });

  add('/api/hh/auth/pin/remove', {
    auth: 'household', methods: ['POST'],
    async handler(req, res, _ctx, access) {
      try {
        const body = await readJson(req, 4096);
        const result = await hh.removePin({
          userId: access.hhUser.id, req, allDevices: !!body?.allDevices,
        });
        send(res, 200, { ok: true }, authHeaders(result.cookie));
      } catch (err) { send(res, 500, { error: String(err?.message || err) }, nostore); }
    },
  });

  add('/api/hh/health', {
    auth: 'public', methods: ['GET'],
    async handler(req, res) {
      try {
        const users = await hh.listUsers();
        send(res, 200, { ok: true, users: users.length }, nostore);
      } catch (err) { send(res, 500, { ok: false, error: String(err?.message || err) }, nostore); }
    },
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // Tasks
  // ═══════════════════════════════════════════════════════════════════════════

  // Open tasks, ordered the way a human reads a list: overdue and due-soon
  // first, undated last, newest-added breaking ties. NULLS LAST is the whole
  // trick — without it Postgres sorts undated tasks to the very top, which
  // buries everything that actually has a deadline.
  // Urgent first, always. Then the human reading order: overdue and due-soon
  // before undated (NULLS LAST is the whole trick — without it Postgres sorts
  // undated tasks to the very top and buries everything with a deadline).
  const OPEN_ORDER = `ORDER BY urgent DESC, due_date ASC NULLS LAST, starred DESC, created_at DESC`;

  /** How long a completed task stays on the Todo screen before it clears. */
  const DONE_WINDOW_DAYS = 5;

  async function listTasks(me, scope) {
    const p = hh.pool();
    const where =
      // 'done' is deliberately a WINDOW, not the whole history. A completed
      // task is useful for a few days ("did I actually do that?") and then it
      // is landfill. Nothing is deleted — the row stays and 'done-all' still
      // returns it — it just stops occupying the screen.
      scope === 'done' ? `${VISIBLE} AND done_at >= NOW() - INTERVAL '${DONE_WINDOW_DAYS} days'`
      : scope === 'done-all' ? `${VISIBLE} AND done_at IS NOT NULL`
      : scope === 'all' ? VISIBLE
      : `${VISIBLE} AND done_at IS NULL`;
    const order = scope === 'done' || scope === 'done-all' ? `ORDER BY done_at DESC` : OPEN_ORDER;
    const { rows } = await p.query(
      `SELECT ${TASK_COLS} FROM hh_tasks WHERE ${where} ${order} LIMIT 500`, [me]);
    return rows;
  }

  add('/api/hh/tasks', {
    auth: 'household', methods: ['GET', 'POST'],
    async handler(req, res, _ctx, access) {
      const me = access.hhUser.id;
      const p = hh.pool();
      try {
        if (req.method === 'GET') {
          const scope = new URL(req.url || '/', 'http://localhost').searchParams.get('scope') || 'open';
          send(res, 200, { tasks: await listTasks(me, scope) }, nostore);
          return;
        }

        const body = await readJson(req, 64_000);
        const action = str(body?.action, 40);

        if (action === 'create') {
          const title = str(body?.title, 300);
          if (!title) { send(res, 400, { error: 'A task needs a title.' }, nostore); return; }
          const { rows } = await p.query(
            `INSERT INTO hh_tasks (owner_id, visibility, title, notes, due_date, starred, project, project_id, urgent)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING ${TASK_COLS}`,
            [me, vis(body?.visibility), title, str(body?.notes, 4000) || null,
             dateOrNull(body?.dueDate), !!body?.starred, str(body?.project, 120) || null,
             Number(body?.projectId) > 0 ? Number(body.projectId) : null, !!body?.urgent]);
          send(res, 200, { ok: true, task: rows[0] }, nostore);
          return;
        }

        const id = Number(body?.id ?? 0);
        if (!Number.isInteger(id) || id <= 0) {
          send(res, 400, { error: 'Missing task id.' }, nostore); return;
        }

        if (action === 'update') {
          // Only the fields actually present are touched, so a partial edit from
          // one screen can't blank a field another screen owns. touched_at moves
          // on every edit — that is what Slipping measures.
          const sets = [];
          const vals = [me, id];
          const put = (sql, v) => { vals.push(v); sets.push(`${sql}=$${vals.length}`); };
          if (body?.title !== undefined) {
            const t = str(body.title, 300);
            if (!t) { send(res, 400, { error: 'A task needs a title.' }, nostore); return; }
            put('title', t);
          }
          if (body?.notes !== undefined) put('notes', str(body.notes, 4000) || null);
          if (body?.dueDate !== undefined) put('due_date', dateOrNull(body.dueDate));
          if (body?.starred !== undefined) put('starred', !!body.starred);
          if (body?.project !== undefined) put('project', str(body.project, 120) || null);
          if (body?.visibility !== undefined) put('visibility', vis(body.visibility));
          if (body?.projectId !== undefined) put('project_id', Number(body.projectId) > 0 ? Number(body.projectId) : null);
          if (body?.urgent !== undefined) put('urgent', !!body.urgent);
          if (!sets.length) { send(res, 400, { error: 'Nothing to update.' }, nostore); return; }
          const { rows } = await p.query(
            `UPDATE hh_tasks SET ${sets.join(', ')}, updated_at=now(), touched_at=now()
              WHERE id=$2 AND ${VISIBLE} RETURNING ${TASK_COLS}`, vals);
          if (!rows[0]) { send(res, 404, { error: 'Not found.' }, nostore); return; }
          send(res, 200, { ok: true, task: rows[0] }, nostore);
          return;
        }

        if (action === 'toggleDone') {
          const { rows } = await p.query(
            `UPDATE hh_tasks
                SET done_at = CASE WHEN done_at IS NULL THEN now() ELSE NULL END,
                    updated_at=now(), touched_at=now()
              WHERE id=$2 AND ${VISIBLE} RETURNING ${TASK_COLS}`, [me, id]);
          if (!rows[0]) { send(res, 404, { error: 'Not found.' }, nostore); return; }
          send(res, 200, { ok: true, task: rows[0] }, nostore);
          return;
        }

        if (action === 'toggleUrgent') {
          const { rows } = await p.query(
            `UPDATE hh_tasks SET urgent = NOT urgent, updated_at=now(), touched_at=now()
              WHERE id=$2 AND ${VISIBLE} RETURNING ${TASK_COLS}`, [me, id]);
          if (!rows[0]) { send(res, 404, { error: 'Not found.' }, nostore); return; }
          send(res, 200, { ok: true, task: rows[0] }, nostore);
          return;
        }

        if (action === 'toggleStar') {
          const { rows } = await p.query(
            `UPDATE hh_tasks SET starred = NOT starred, updated_at=now(), touched_at=now()
              WHERE id=$2 AND ${VISIBLE} RETURNING ${TASK_COLS}`, [me, id]);
          if (!rows[0]) { send(res, 404, { error: 'Not found.' }, nostore); return; }
          send(res, 200, { ok: true, task: rows[0] }, nostore);
          return;
        }

        // "I looked at this, stop calling it slipping" — resets the clock
        // without pretending the task changed.
        if (action === 'touch') {
          const { rows } = await p.query(
            `UPDATE hh_tasks SET touched_at=now() WHERE id=$2 AND ${VISIBLE} RETURNING ${TASK_COLS}`,
            [me, id]);
          if (!rows[0]) { send(res, 404, { error: 'Not found.' }, nostore); return; }
          send(res, 200, { ok: true, task: rows[0] }, nostore);
          return;
        }

        if (action === 'delete') {
          // Deliberately stricter than VISIBLE: you can complete or edit a
          // shared task, but only its owner can destroy it. Deletion is the one
          // action with no undo.
          const { rowCount } = await p.query(
            `DELETE FROM hh_tasks WHERE id=$2 AND owner_id=$1`, [me, id]);
          if (!rowCount) {
            send(res, 403, { error: 'Only the person who added it can delete it.' }, nostore);
            return;
          }
          send(res, 200, { ok: true }, nostore);
          return;
        }

        send(res, 400, { error: `Unknown action: ${action}` }, nostore);
      } catch (err) { send(res, 500, { error: String(err?.message || err) }, nostore); }
    },
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // Notes (the Resurfacing pool)
  // ═══════════════════════════════════════════════════════════════════════════

  add('/api/hh/notes', {
    auth: 'household', methods: ['GET', 'POST'],
    async handler(req, res, _ctx, access) {
      const me = access.hhUser.id;
      const p = hh.pool();
      try {
        if (req.method === 'GET') {
          const { rows } = await p.query(
            `SELECT id, owner_id, visibility, kind, body, created_at, last_surfaced_at
               FROM hh_notes WHERE ${VISIBLE} ORDER BY created_at DESC LIMIT 500`, [me]);
          send(res, 200, { notes: rows }, nostore);
          return;
        }
        const body = await readJson(req, 64_000);
        const action = str(body?.action, 40);

        if (action === 'create') {
          const text = str(body?.body, 4000);
          if (!text) { send(res, 400, { error: 'Nothing to save.' }, nostore); return; }
          const kind = ['note', 'quote', 'journal'].includes(body?.kind) ? body.kind : 'note';
          const { rows } = await p.query(
            `INSERT INTO hh_notes (owner_id, visibility, kind, body) VALUES ($1,$2,$3,$4)
             RETURNING id, owner_id, visibility, kind, body, created_at, last_surfaced_at`,
            [me, vis(body?.visibility), kind, text]);
          send(res, 200, { ok: true, note: rows[0] }, nostore);
          return;
        }

        if (action === 'delete') {
          const id = Number(body?.id ?? 0);
          const { rowCount } = await p.query(
            `DELETE FROM hh_notes WHERE id=$2 AND owner_id=$1`, [me, id]);
          if (!rowCount) { send(res, 403, { error: 'Only the person who saved it can delete it.' }, nostore); return; }
          send(res, 200, { ok: true }, nostore);
          return;
        }

        send(res, 400, { error: `Unknown action: ${action}` }, nostore);
      } catch (err) { send(res, 500, { error: String(err?.message || err) }, nostore); }
    },
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // Settings
  // ═══════════════════════════════════════════════════════════════════════════

  add('/api/hh/settings', {
    auth: 'household', methods: ['GET', 'POST'],
    async handler(req, res, _ctx, access) {
      const me = access.hhUser.id;
      try {
        if (req.method === 'GET') {
          send(res, 200, { settings: await hh.getSettings(me) }, nostore);
          return;
        }
        const body = await readJson(req, 8192);
        if (body?.slippingDays !== undefined) {
          const d = Number(body.slippingDays);
          // Clamped rather than rejected: 0 would flag every task the moment
          // it's created, and there's no sane reason to go past a year.
          if (!Number.isFinite(d) || d < 1 || d > 365) {
            send(res, 400, { error: 'Slipping days must be between 1 and 365.' }, nostore);
            return;
          }
          await hh.setSetting(me, 'slippingDays', Math.round(d));
        }
        if (body?.weatherZip !== undefined) {
          const z = str(body.weatherZip, 5);
          // Empty clears it — that is how you turn the weather tile off, so it
          // must not be rejected as invalid.
          if (z !== '' && !/^\d{5}$/.test(z)) {
            send(res, 400, { error: 'ZIP must be five digits.' }, nostore);
            return;
          }
          await hh.setSetting(me, 'weatherZip', z);
        }
        send(res, 200, { ok: true, settings: await hh.getSettings(me) }, nostore);
      } catch (err) { send(res, 500, { error: String(err?.message || err) }, nostore); }
    },
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // Weather
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // A household-scoped copy of the logic in api-router.js's /api/weather.
  //
  // NOT a call through to that route: it is registered auth:'subscriber' and
  // resolves an active trading-app session, which an hh_session cookie will
  // never satisfy — budget.cbedge.net would get a 401 forever. The upstreams
  // are keyless and the whole thing is ~30 lines, so a second registration is
  // cheaper than plumbing a second auth mode through the shared route.
  //
  // If the WMO table or the provider changes, BOTH copies need the edit.

  const WMO = {
    0: 'Clear', 1: 'Mainly Clear', 2: 'Partly Cloudy', 3: 'Overcast',
    45: 'Fog', 48: 'Rime Fog', 51: 'Light Drizzle', 53: 'Drizzle', 55: 'Heavy Drizzle',
    61: 'Light Rain', 63: 'Rain', 65: 'Heavy Rain', 66: 'Freezing Rain', 67: 'Freezing Rain',
    71: 'Light Snow', 73: 'Snow', 75: 'Heavy Snow', 77: 'Snow Grains',
    80: 'Rain Showers', 81: 'Rain Showers', 82: 'Violent Showers',
    85: 'Snow Showers', 86: 'Snow Showers', 95: 'Thunderstorm', 96: 'Thunderstorm', 99: 'Thunderstorm',
  };

  /**
   * ZIP → { at, payload }. The weather does not change in ten minutes, and
   * Today mounts this on every navigation back to the home tab — without a
   * cache a phone left open all day is a few hundred calls to somebody else's
   * free API. Process-local, so a restart just re-warms it.
   */
  const wxCache = new Map();
  const WX_TTL_MS = 10 * 60 * 1000;

  add('/api/hh/weather', {
    auth: 'household', methods: ['GET'],
    async handler(req, res) {
      const zip = str(new URL(req.url || '/', 'http://localhost').searchParams.get('zip'), 5);
      if (!/^\d{5}$/.test(zip)) {
        send(res, 400, { error: 'Valid 5-digit US ZIP required' }, nostore);
        return;
      }

      const hit = wxCache.get(zip);
      if (hit && Date.now() - hit.at < WX_TTL_MS) { send(res, 200, hit.payload, nostore); return; }

      try {
        // Primary geocoder: zippopotam. Nominatim is the fallback.
        let loc = null;
        try {
          const geoRes = await fetch(`https://api.zippopotam.us/us/${zip}`, { cache: 'no-store' });
          if (geoRes.ok) {
            const geo = await geoRes.json();
            const p = geo?.places?.[0];
            if (p) loc = { latitude: p.latitude, longitude: p.longitude,
                           name: p['place name'], admin1: p['state abbreviation'] };
          }
        } catch { /* fall through to Nominatim */ }

        if (!loc) {
          const nomRes = await fetch(
            `https://nominatim.openstreetmap.org/search?postalcode=${zip}&country=US&format=json&addressdetails=1&limit=1`,
            { cache: 'no-store', headers: { 'User-Agent': 'cbedge-household/1.0' } });
          if (nomRes.ok) {
            const arr = await nomRes.json();
            const nm = Array.isArray(arr) ? arr[0] : null;
            if (nm) loc = {
              latitude: nm.lat, longitude: nm.lon,
              name: nm.address?.town || nm.address?.city || nm.address?.village
                    || nm.display_name?.split(',')[0] || zip,
              admin1: nm.address?.['ISO3166-2-lvl4']?.split('-')[1] || '',
            };
          }
        }

        if (!loc) { send(res, 404, { error: 'ZIP not found' }, nostore); return; }

        const wRes = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}`
          + `&current=temperature_2m,weather_code&temperature_unit=fahrenheit&timezone=auto`,
          { cache: 'no-store' });
        const w = await wRes.json();
        const cur = w?.current;
        if (!cur) { send(res, 502, { error: 'Weather unavailable' }, nostore); return; }

        const payload = {
          tempF: Math.round(cur.temperature_2m),
          condition: WMO[cur.weather_code] ?? '—',
          code: cur.weather_code,
          place: `${loc.name}${loc.admin1 ? ', ' + loc.admin1 : ''}`,
        };
        wxCache.set(zip, { at: Date.now(), payload });
        send(res, 200, payload, nostore);
      } catch (err) {
        send(res, 500, { error: 'Weather fetch failed', detail: String(err?.message || err) }, nostore);
      }
    },
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // Google Calendar (read-only)
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // /connect and /callback are BROWSER NAVIGATIONS, not fetches. They are
  // registered auth:'public' and do their own session check, because a
  // navigation that 401s with JSON dumps raw text on the screen — these must
  // always end in a redirect a person can read.
  //
  // The hh_session cookie is SameSite=Lax, which permits top-level GET
  // navigations, so it IS present when Google redirects back here. (It would
  // NOT survive a POST callback — do not change the response_type to one that
  // posts.)

  const redirect = (res, to) => {
    res.statusCode = 302;
    res.setHeader('Location', to);
    res.setHeader('Cache-Control', NO_STORE);
    res.end();
  };

  // ── One day, two sources ───────────────────────────────────────────────────
  //
  // Google and the subscribed ICS feeds are merged HERE rather than inside
  // either lib, so neither has to know the other exists. The feed events are
  // shaped identically (same keys, same RFC3339-with-offset starts), so the
  // client cannot tell which list an event came from — and shouldn't: on a
  // screen answering "what is today", provenance is not the question.

  /** All-day first, then chronological. By instant, never by string: the two
   *  sources format their offsets differently and a string sort interleaves
   *  them wrongly around midnight. */
  const startMs = (e) => (e.allDay
    ? Date.parse(`${String(e.start).slice(0, 10)}T00:00:00Z`)
    : Date.parse(e.start));
  const byDayOrder = (a, b) => (b.allDay ? 1 : 0) - (a.allDay ? 1 : 0) || startMs(a) - startMs(b);

  async function calendarDay(u, date, { force = false } = {}) {
    const g = gcal
      ? await gcal.eventsForDay(u.id, u.tz, date, { force })
      : { events: [], error: 'not-configured' };

    let f = null;
    if (icsFeeds && icsFeeds.available()) {
      try {
        if (force) await icsFeeds.refreshAll(u.id);
        f = await icsFeeds.eventsForDay(u.id, u.tz, date);
      } catch { f = null; }
    }
    // No feeds subscribed → the Google answer verbatim, error and all.
    if (!f || !f.feedCount) return { date, ...g };

    const events = [...(g.events || []), ...f.events].sort(byDayOrder).slice(0, 60);
    const upcoming = [...(g.upcoming || []), ...f.upcoming]
      .sort((a, b) => startMs(a) - startMs(b)).slice(0, 5);

    const out = {
      date,
      events,
      upcoming,
      source: g.source,
      calendarCount: (g.calendarCount || 0) + f.feedCount,
      feedCount: f.feedCount,
      partialFailures: (g.partialFailures || 0) + f.partialFailures,
      syncedAt: new Date().toISOString(),
    };
    // A Google error that would blank a card which DOES have feed events is
    // worse than no message at all — the feeds are answering, so the card is
    // not broken. Kept only when there is genuinely nothing to show.
    if (g.error && !events.length && !upcoming.length) out.error = g.error;
    return out;
  }

  // ── Subscribed ICS feeds ───────────────────────────────────────────────────

  if (icsFeeds && icsFeeds.available()) {
    add('/api/hh/calendar/feeds', {
      auth: 'household', methods: ['GET', 'POST'],
      async handler(req, res, _ctx, access) {
        const uid = access.hhUser.id;
        try {
          if ((req.method || 'GET').toUpperCase() === 'GET') {
            send(res, 200, await icsFeeds.list(uid), nostore); return;
          }
          const body = await readJson(req, 8_000);
          const action = String(body?.action || '');

          if (action === 'add') {
            const r = await icsFeeds.add(uid, body.url, {
              name: body.name, colour: body.colour,
              shareWithHousehold: body.shareWithHousehold,
            });
            // 400 with a readable message: this one IS a form error, unlike the
            // events endpoints where a failure is a shaped 200.
            if (r.error) { send(res, 400, { error: r.error }, nostore); return; }
            send(res, 200, await icsFeeds.list(uid), nostore); return;
          }
          if (action === 'remove') {
            const ok = await icsFeeds.remove(uid, body.id);
            if (!ok) { send(res, 404, { error: 'No such feed.' }, nostore); return; }
            send(res, 200, await icsFeeds.list(uid), nostore); return;
          }
          if (action === 'update') {
            const r = await icsFeeds.update(uid, body.id, body);
            if (r.error) { send(res, 400, { error: r.error }, nostore); return; }
            send(res, 200, await icsFeeds.list(uid), nostore); return;
          }
          if (action === 'refresh') {
            await icsFeeds.refreshAll(uid);
            send(res, 200, await icsFeeds.list(uid), nostore); return;
          }
          send(res, 400, { error: 'Unknown action.' }, nostore);
        } catch (err) { send(res, 500, { error: String(err?.message || err) }, nostore); }
      },
    });
  }

  if (gcal) {
    add('/api/hh/calendar/connect', {
      auth: 'public', methods: ['GET'],
      async handler(req, res) {
        const u = await hh.userFromRequest(req);
        if (!u) { redirect(res, '/'); return; }
        if (!gcal.configured()) { redirect(res, '/settings?calendar=unconfigured'); return; }
        redirect(res, gcal.authUrl(u.id));
      },
    });

    add('/api/hh/calendar/callback', {
      auth: 'public', methods: ['GET'],
      async handler(req, res) {
        try {
          const url = new URL(req.url || '/', 'http://localhost');
          const err = url.searchParams.get('error');
          // The user pressed Cancel on Google's consent screen. Not an error
          // worth a scary page — just send them back.
          if (err) { redirect(res, `/settings?calendar=${encodeURIComponent(err)}`); return; }

          const u = await hh.userFromRequest(req);
          if (!u) { redirect(res, '/'); return; }

          const state = gcal.verifyState(url.searchParams.get('state'));
          // The state is HMAC-signed by us AND must match the signed-in user.
          // Signature alone would let someone paste their own callback URL into
          // the other person's browser and bind THEIR calendar to that account.
          if (!state || state.uid !== u.id) {
            redirect(res, '/settings?calendar=bad-state'); return;
          }

          const code = url.searchParams.get('code');
          if (!code) { redirect(res, '/settings?calendar=no-code'); return; }

          await gcal.connect(u.id, code);
          redirect(res, '/settings?calendar=connected');
        } catch (e) {
          console.warn('[household] calendar callback failed:', e?.message || e);
          redirect(res, `/settings?calendar=${encodeURIComponent(String(e?.message || 'failed').slice(0, 120))}`);
        }
      },
    });

    add('/api/hh/calendar/status', {
      auth: 'household', methods: ['GET'],
      async handler(req, res, _ctx, access) {
        send(res, 200, await gcal.status(access.hhUser.id), nostore);
      },
    });

    // Every calendar the connected account can see. A shared family calendar is
    // a SEPARATE calendar in this list, not part of `primary` — which is why
    // reading only primary would never show one of its events.
    add('/api/hh/calendar/calendars', {
      auth: 'household', methods: ['GET'],
      async handler(req, res, _ctx, access) {
        send(res, 200, await gcal.listCalendars(access.hhUser.id), nostore);
      },
    });

    // Which calendars to show, and whether the household sees them.
    add('/api/hh/calendar/select', {
      auth: 'household', methods: ['POST'],
      async handler(req, res, _ctx, access) {
        try {
          const body = await readJson(req, 32_000);
          const calendarIds = Array.isArray(body?.calendarIds) ? body.calendarIds : undefined;
          const shareWithHousehold = typeof body?.shareWithHousehold === 'boolean'
            ? body.shareWithHousehold : undefined;
          if (calendarIds === undefined && shareWithHousehold === undefined) {
            send(res, 400, { error: 'Nothing to update.' }, nostore); return;
          }
          const okUpd = await gcal.saveSelection(access.hhUser.id, { calendarIds, shareWithHousehold });
          if (!okUpd) { send(res, 404, { error: 'No Google connection to update.' }, nostore); return; }
          send(res, 200, await gcal.listCalendars(access.hhUser.id), nostore);
        } catch (err) { send(res, 500, { error: String(err?.message || err) }, nostore); }
      },
    });

    add('/api/hh/calendar/disconnect', {
      auth: 'household', methods: ['POST'],
      async handler(req, res, _ctx, access) {
        try { await gcal.disconnect(access.hhUser.id); send(res, 200, { ok: true }, nostore); }
        catch (err) { send(res, 500, { error: String(err?.message || err) }, nostore); }
      },
    });

    // Fetched by the client SEPARATELY from /api/hh/today, on purpose. A call
    // out to Google can take half a second; folding it into Today would hold
    // the entire screen hostage to a third party. Today paints from our own
    // database immediately and the calendar card fills in when it fills in.
    add('/api/hh/calendar/events', {
      auth: 'household', methods: ['GET'],
      async handler(req, res, _ctx, access) {
        const u = access.hhUser;
        const qDate = new URL(req.url || '/', 'http://localhost').searchParams.get('date');
        const date = /^\d{4}-\d{2}-\d{2}$/.test(String(qDate || '')) ? qDate : todayIn(u.tz);
        // Always 200 with a shaped body. The card renders its own state from
        // `error`; a non-200 here would just become a red screen for a calendar
        // hiccup nobody needs to act on.
        send(res, 200, await calendarDay(u, date), nostore);
      },
    });

    // Sync on demand — the button in Settings. Same body as /events, but it
    // skips the 60s cache and asks Google now.
    //
    // POST, not a `?refresh=1` on the GET above, deliberately: this is the one
    // calendar read that must never be replayed by a browser prefetch, a
    // back/forward restore or a retried GET. The lib rate-limits it per user,
    // so a stuck finger costs nothing.
    add('/api/hh/calendar/sync', {
      auth: 'household', methods: ['POST'],
      async handler(req, res, _ctx, access) {
        const u = access.hhUser;
        // Date from the query string, so this works with an empty body — which
        // is what the client sends.
        const qDate = new URL(req.url || '/', 'http://localhost').searchParams.get('date');
        const date = /^\d{4}-\d{2}-\d{2}$/.test(String(qDate || '')) ? qDate : todayIn(u.tz);
        // Always 200 with a shaped body, same as /events — a Google hiccup is a
        // line in the card, not a failed request the UI has to explain. Sync
        // forces the subscribed feeds to re-read too; "sync" to a person means
        // everything on this screen, not just the Google half.
        send(res, 200, await calendarDay(u, date, { force: true }), nostore);
      },
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Lists — meals by day, and the grocery list they feed
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // Week / Shop / Lists are three VIEWS over two tables, never three copies.
  // Ticking an item in the shop marks the same row that sits under Tuesday on
  // the week board — see the header of _lib-household-lists.cjs.

  if (hlists && hlists.available()) {
    add('/api/hh/lists', {
      auth: 'household', methods: ['GET', 'POST'],
      async handler(req, res, _ctx, access) {
        const u = access.hhUser;
        try {
          if (req.method === 'GET') {
            const d = new URL(req.url || '/', 'http://localhost').searchParams.get('week');
            send(res, 200, await hlists.getWeek(u.id, u.tz, d), nostore);
            return;
          }
          const body = await readJson(req, 64_000);
          const action = str(body?.action, 40);
          const id = Number(body?.id ?? 0);

          switch (action) {
            case 'addItem':
              send(res, 200, { ok: true, item: await hlists.addItem(u.id, {
                text: body?.text, qty: body?.qty, aisle: body?.aisle,
                list: body?.list, mealId: body?.mealId, visibility: body?.visibility,
              }) }, nostore);
              return;
            case 'toggleItem':
              send(res, 200, { ok: true, item: await hlists.toggleItem(u.id, id) }, nostore); return;
            case 'updateItem':
              send(res, 200, { ok: true, item: await hlists.updateItem(u.id, id, {
                text: body?.text, qty: body?.qty, aisle: body?.aisle, visibility: body?.visibility,
              }) }, nostore);
              return;
            case 'deleteItem':
              await hlists.deleteItem(u.id, id); send(res, 200, { ok: true }, nostore); return;
            case 'clearChecked':
              send(res, 200, { ok: true, removed: await hlists.clearChecked(u.id) }, nostore); return;
            case 'addMeal':
              send(res, 200, { ok: true, meal: await hlists.addMeal(u.id, {
                day: body?.day, title: body?.title, notes: body?.notes, visibility: body?.visibility,
              }) }, nostore);
              return;
            case 'updateMeal':
              send(res, 200, { ok: true, meal: await hlists.updateMeal(u.id, id, {
                title: body?.title, notes: body?.notes, day: body?.day,
              }) }, nostore);
              return;
            case 'deleteMeal':
              await hlists.deleteMeal(u.id, id); send(res, 200, { ok: true }, nostore); return;
            default:
              send(res, 400, { error: `Unknown action: ${action}` }, nostore);
          }
        } catch (err) {
          send(res, 400, { error: String(err?.message || err) }, nostore);
        }
      },
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Projects, milestones, time
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // Progress is measured from MILESTONES, never from task counts — see the
  // header of _lib-household-projects.cjs. Milestones and time entries inherit
  // their permission from the PROJECT, resolved by joining rather than trusting
  // an id from the client.

  if (hprojects && hprojects.available()) {
    add('/api/hh/projects', {
      auth: 'household', methods: ['GET', 'POST'],
      async handler(req, res, _ctx, access) {
        const u = access.hhUser;
        try {
          if (req.method === 'GET') {
            const q = new URL(req.url || '/', 'http://localhost').searchParams;
            const id = Number(q.get('id') || 0);
            if (id > 0) {
              const p = await hprojects.getProject(u.id, id);
              if (!p) { send(res, 404, { error: 'Not found.' }, nostore); return; }
              send(res, 200, { project: p }, nostore); return;
            }
            send(res, 200, {
              projects: await hprojects.listProjects(u.id, { includeArchived: q.get('archived') === '1' }),
            }, nostore);
            return;
          }

          const body = await readJson(req, 64_000);
          const action = str(body?.action, 40);
          const id = Number(body?.id ?? 0);

          switch (action) {
            case 'create':
              send(res, 200, { ok: true, project: await hprojects.createProject(u.id, {
                name: body?.name, description: body?.description, visibility: body?.visibility,
                targetDate: body?.targetDate, color: body?.color, status: body?.status,
              }) }, nostore);
              return;
            case 'update':
              send(res, 200, { ok: true, project: await hprojects.updateProject(u.id, id, {
                name: body?.name, description: body?.description, visibility: body?.visibility,
                status: body?.status, color: body?.color, targetDate: body?.targetDate,
              }) }, nostore);
              return;
            case 'archive':
              send(res, 200, { ok: true, project: await hprojects.archiveProject(u.id, id, body?.archived !== false) }, nostore);
              return;
            case 'delete':
              await hprojects.deleteProject(u.id, id);
              send(res, 200, { ok: true }, nostore); return;
            case 'addMilestone':
              send(res, 200, { ok: true, milestone: await hprojects.addMilestone(u.id, id, body?.title) }, nostore);
              return;
            case 'toggleMilestone':
              send(res, 200, { ok: true, milestone: await hprojects.toggleMilestone(u.id, Number(body?.milestoneId)) }, nostore);
              return;
            case 'updateMilestone':
              send(res, 200, { ok: true, milestone: await hprojects.updateMilestone(u.id, Number(body?.milestoneId), body?.title) }, nostore);
              return;
            case 'deleteMilestone':
              await hprojects.deleteMilestone(u.id, Number(body?.milestoneId));
              send(res, 200, { ok: true }, nostore); return;
            case 'logTime':
              send(res, 200, { ok: true, entry: await hprojects.logTime(u.id, id, {
                minutes: body?.minutes, day: body?.day, note: body?.note,
              }, u.tz) }, nostore);
              return;
            case 'deleteTime':
              await hprojects.deleteTime(u.id, Number(body?.entryId));
              send(res, 200, { ok: true }, nostore); return;
            default:
              send(res, 400, { error: `Unknown action: ${action}` }, nostore);
          }
        } catch (err) {
          send(res, 400, { error: String(err?.message || err) }, nostore);
        }
      },
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Routines & habits
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // Deliberately NOT part of /api/hh/tasks. A routine is a recurring intention
  // that never completes; a task is done once and gone. Mixing them leaves your
  // to-do list permanently full of things you do every day, or makes habits
  // vanish the moment you tick them.

  if (hroutines && hroutines.available()) {
    add('/api/hh/routines', {
      auth: 'household', methods: ['GET', 'POST'],
      async handler(req, res, _ctx, access) {
        const u = access.hhUser;
        try {
          if (req.method === 'GET') {
            const d = new URL(req.url || '/', 'http://localhost').searchParams.get('date');
            send(res, 200, await hroutines.getRoutines(u.id, u.tz, d), nostore);
            return;
          }
          const body = await readJson(req, 32_000);
          const action = str(body?.action, 40);

          if (action === 'create') {
            send(res, 200, { ok: true, routine: await hroutines.create(u.id, {
              title: body?.title, block: body?.block, visibility: body?.visibility,
            }) }, nostore);
            return;
          }

          const id = Number(body?.id ?? 0);
          if (!Number.isInteger(id) || id <= 0) { send(res, 400, { error: 'Missing id.' }, nostore); return; }

          if (action === 'toggle') {
            send(res, 200, { ok: true, ...(await hroutines.toggle(u.id, id, u.tz, body?.date)) }, nostore);
            return;
          }
          if (action === 'update') {
            send(res, 200, { ok: true, routine: await hroutines.update(u.id, id, {
              title: body?.title, block: body?.block,
              visibility: body?.visibility, sortOrder: body?.sortOrder,
            }) }, nostore);
            return;
          }
          if (action === 'archive') { await hroutines.archive(u.id, id); send(res, 200, { ok: true }, nostore); return; }
          if (action === 'delete') { await hroutines.remove(u.id, id); send(res, 200, { ok: true }, nostore); return; }

          send(res, 400, { error: `Unknown action: ${action}` }, nostore);
        } catch (err) {
          send(res, 400, { error: String(err?.message || err) }, nostore);
        }
      },
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Recipes — recipe.cbedge.net
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // GET  /api/hh/recipes?id=N            one recipe, ingredients and steps included
  // GET  /api/hh/recipes?q=&category=    the cookbook index (no ingredients — see CARD_COLS)
  // POST /api/hh/recipes  { action }     import | create | update | delete |
  //                                      favorite | cooked | addToList | plan
  //
  // `import` is the only action that does NOT write to the database. It returns
  // a draft for the review screen; nothing is saved until `create`. That split
  // is what keeps a half-read blog post out of the cookbook.

  if (hrecipes && hrecipes.available()) {
    add('/api/hh/recipes', {
      auth: 'household', methods: ['GET', 'POST'],
      async handler(req, res, _ctx, access) {
        const u = access.hhUser;
        try {
          if (req.method === 'GET') {
            const p = new URL(req.url || '/', 'http://localhost').searchParams;
            const id = Number(p.get('id') || 0);
            if (Number.isInteger(id) && id > 0) {
              send(res, 200, { recipe: await hrecipes.getRecipe(u.id, id) }, nostore);
              return;
            }
            send(res, 200, await hrecipes.listRecipes(u.id, {
              q: p.get('q'), category: p.get('category'), main: p.get('main'),
              sort: p.get('sort'), favorite: p.get('favorite') === '1',
              needsReview: p.get('review') === '1',
            }), nostore);
            return;
          }

          // 250KB: an import can carry a pasted recipe (capped at 60k chars in
          // the lib) and a create carries the whole reviewed draft back.
          const body = await readJson(req, 250_000);
          const action = str(body?.action, 40);

          if (action === 'import') {
            // No id, no write — just a draft for the review screen.
            // `force` skips the "is this even a recipe" gate — offered on the
            // Add screen when the gate rejects something you know is food.
            send(res, 200, { ok: true, draft: await hrecipes.importRecipe({
              url: body?.url, text: body?.text, force: !!body?.force,
            }) }, nostore);
            return;
          }
          if (action === 'create') {
            send(res, 200, { ok: true, recipe: await hrecipes.createRecipe(u.id, body?.recipe || body) }, nostore);
            return;
          }

          const id = Number(body?.id ?? 0);
          if (!Number.isInteger(id) || id <= 0) { send(res, 400, { error: 'Missing id.' }, nostore); return; }

          if (action === 'update') {
            send(res, 200, { ok: true, recipe: await hrecipes.updateRecipe(u.id, id, body?.patch || body) }, nostore);
            return;
          }
          if (action === 'favorite') {
            send(res, 200, { ok: true, recipe: await hrecipes.toggleFavorite(u.id, id) }, nostore);
            return;
          }
          if (action === 'cooked') {
            send(res, 200, { ok: true, recipe: await hrecipes.markCooked(u.id, id) }, nostore);
            return;
          }
          if (action === 'delete') {
            await hrecipes.deleteRecipe(u.id, id);
            send(res, 200, { ok: true }, nostore);
            return;
          }
          // Writes real hh_list_items rows — the grocery list on
          // budget.cbedge.net picks them up with no sync step.
          if (action === 'addToList') {
            send(res, 200, { ok: true, ...(await hrecipes.addToList(u.id, id, {
              servings: body?.servings, only: body?.only,
            })) }, nostore);
            return;
          }
          // …and a real hh_meals row, so the week board shows it.
          if (action === 'plan') {
            send(res, 200, { ok: true, ...(await hrecipes.planMeal(u.id, id, {
              day: dateOrNull(body?.day), servings: body?.servings,
              withList: body?.withList !== false,
            })) }, nostore);
            return;
          }

          send(res, 400, { error: `Unknown action: ${action}` }, nostore);
        } catch (err) {
          send(res, 400, { error: String(err?.message || err) }, nostore);
        }
      },
    });
  }

  // ── The week ──────────────────────────────────────────────────────────────
  //
  // GET  /api/hh/recipes/week[?date=YYYY-MM-DD]   what's planned, by day
  // POST /api/hh/recipes/week {mealId, remove}    take it off the plan
  // POST /api/hh/recipes/week {mealId, day}       move it to another day
  //
  // Reads and writes hh_meals — the SAME table budget.cbedge.net's week board
  // uses. There is no second plan to keep in step.

  if (hrecipes && hrecipes.available()) {
    add('/api/hh/recipes/week', {
      auth: 'household', methods: ['GET', 'POST'],
      async handler(req, res, _ctx, access) {
        const u = access.hhUser;
        try {
          if (req.method === 'GET') {
            const d = new URL(req.url || '/', 'http://localhost').searchParams.get('date');
            send(res, 200, await hrecipes.getPlannedWeek(u.id, u.tz, d), nostore);
            return;
          }
          const body = await readJson(req, 8192);
          const mealId = Number(body?.mealId ?? 0);
          if (!Number.isInteger(mealId) || mealId <= 0) { send(res, 400, { error: 'Missing mealId.' }, nostore); return; }

          if (body?.remove) {
            await hrecipes.unplanMeal(u.id, mealId);
            send(res, 200, { ok: true }, nostore);
            return;
          }
          send(res, 200, { ok: true, meal: await hrecipes.moveMeal(u.id, mealId, dateOrNull(body?.day)) }, nostore);
        } catch (err) {
          send(res, 400, { error: String(err?.message || err) }, nostore);
        }
      },
    });
  }

  // ── Bulk import ───────────────────────────────────────────────────────────
  //
  // POST /api/hh/recipes/bulk  {urls}        start a job → {job:{id,...}}
  // POST /api/hh/recipes/bulk  {id, cancel}  stop it
  // POST /api/hh/recipes/bulk  {id, retry}   requeue just the failures
  // GET  /api/hh/recipes/bulk[?id=N]         progress; no id = the latest job
  // GET  /api/hh/recipes/bulk?misses=1        every link never imported, all jobs
  //
  // The POST returns as soon as the rows are written and does NOT wait for the
  // imports. Thirty TikToks is minutes of fetching and AI calls — well past
  // nginx's 180s and far past how long a phone screen stays awake — so the work
  // runs in this process and the client polls this route.

  if (hrecipes && hrecipes.available()) {
    add('/api/hh/recipes/bulk', {
      auth: 'household', methods: ['GET', 'POST'],
      async handler(req, res, _ctx, access) {
        const u = access.hhUser;
        try {
          if (req.method === 'GET') {
            const p = new URL(req.url || '/', 'http://localhost').searchParams;
            // ?misses=1 — everything never imported, across EVERY job. The
            // by-hand pile, and the reason it isn't per-job: twenty-five
            // batches is twenty-five panels nobody will open one at a time.
            if (p.get('misses') === '1') {
              send(res, 200, await hrecipes.listImportMisses(u.id), nostore);
              return;
            }
            const id = Number(p.get('id') || 0);
            const out = Number.isInteger(id) && id > 0
              ? await hrecipes.getImportJob(u.id, id)
              : await hrecipes.latestImportJob(u.id);
            send(res, 200, out || { job: null, items: [] }, nostore);
            return;
          }

          // 100KB: sixty URLs is a few KB. This is a paste box, not an upload.
          const body = await readJson(req, 100_000);

          if (body?.retry) {
            const id = Number(body?.id ?? 0);
            if (!Number.isInteger(id) || id <= 0) { send(res, 400, { error: 'Missing id.' }, nostore); return; }
            send(res, 200, await hrecipes.retryImportJob(u.id, id), nostore);
            return;
          }

          if (body?.cancel) {
            const id = Number(body?.id ?? 0);
            if (!Number.isInteger(id) || id <= 0) { send(res, 400, { error: 'Missing id.' }, nostore); return; }
            send(res, 200, await hrecipes.cancelImportJob(u.id, id), nostore);
            return;
          }

          send(res, 200, { ok: true, ...(await hrecipes.createImportJob(u.id, body?.urls)) }, nostore);
        } catch (err) {
          send(res, 400, { error: String(err?.message || err) }, nostore);
        }
      },
    });
  }

  // ── Recipe photos ─────────────────────────────────────────────────────────
  //
  // GET  /api/hh/recipes/image?id=N[&v=etag]   the bytes
  // POST /api/hh/recipes/image  {id, dataUrl}  replace it (browser upload)
  // POST /api/hh/recipes/image  {id, remove:true}
  //
  // A separate route from /api/hh/recipes because this one writes BINARY, not
  // JSON — it bypasses send() and talks to the response directly — and because
  // an upload body is measured in megabytes where every other action here is
  // measured in kilobytes.

  if (hrecipes && hrecipes.available()) {
    add('/api/hh/recipes/image', {
      auth: 'household', methods: ['GET', 'POST'],
      async handler(req, res, _ctx, access) {
        const u = access.hhUser;
        try {
          if (req.method === 'GET') {
            const p = new URL(req.url || '/', 'http://localhost').searchParams;
            const id = Number(p.get('id') || 0);
            if (!Number.isInteger(id) || id <= 0) { send(res, 400, { error: 'Missing id.' }, nostore); return; }

            const img = await hrecipes.readImage(u.id, id);
            if (!img) { send(res, 404, { error: 'No image.' }, nostore); return; }

            const tag = `"${img.etag}"`;
            // Conditional request — a phone that already has this photo gets 33
            // bytes back instead of 300KB.
            if ((req.headers['if-none-match'] || '') === tag) {
              res.writeHead(304, { ETag: tag });
              res.end();
              return;
            }

            // immutable + a year is safe ONLY because the client appends ?v=etag
            // (see IMG_ETAG in _lib-household-recipes.cjs). Replacing the photo
            // changes the URL, so nothing serves a stale one.
            res.writeHead(200, {
              'Content-Type': img.mime,
              'Content-Length': img.bytes.length,
              'Cache-Control': p.get('v') ? 'private, max-age=31536000, immutable' : 'private, max-age=60',
              ETag: tag,
            });
            res.end(img.bytes);
            return;
          }

          // 12MB: a browser-downscaled JPEG is a few hundred KB, base64 inflates
          // it by a third, and the lib caps the decoded bytes at 8MB anyway.
          // This is the outer guard, not the real limit.
          const body = await readJson(req, 12 * 1024 * 1024);
          const id = Number(body?.id ?? 0);
          if (!Number.isInteger(id) || id <= 0) { send(res, 400, { error: 'Missing id.' }, nostore); return; }

          if (body?.remove) {
            await hrecipes.deleteImage(u.id, id);
            send(res, 200, { ok: true, removed: true }, nostore);
            return;
          }
          if (body?.dataUrl) {
            const out = await hrecipes.setImageFromDataUrl(u.id, id, body.dataUrl);
            send(res, 200, { ok: true, ...out }, nostore);
            return;
          }
          // Re-copy from a URL — the repair path when a capture failed at import
          // time, and how "paste an image link" is implemented.
          if (body?.url) {
            // captureImage takes a bare recipe id, so the visibility check has
            // to happen here — it is the one image path that doesn't get it for
            // free from getRecipe. Throws 'Not found.' if this user can't see it.
            await hrecipes.getRecipe(u.id, id);
            const out = await hrecipes.captureImage(id, body.url);
            if (!out) { send(res, 400, { error: "Couldn't read an image from that link." }, nostore); return; }
            send(res, 200, { ok: true, ...out }, nostore);
            return;
          }
          send(res, 400, { error: 'Nothing to store.' }, nostore);
        } catch (err) {
          send(res, 400, { error: String(err?.message || err) }, nostore);
        }
      },
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Budget
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // Scoped by the signed-in user's budget_profile_key, which defaults to 'owner'
  // — the single profile /api/budget has always used. So this reads the EXISTING
  // register with no migration, and a payment entered here appears on
  // /owner/budget immediately (and vice versa). There is no second budget.
  //
  // Recurring bills are expanded at read time from the rules, using logic ported
  // verbatim from the desktop page. Marking one paid materialises it as a real
  // row under `__recur__:<ruleId>:<date>`, which is exactly how the desktop
  // records it — so neither surface can double-pay a bill the other settled.

  if (hbudget && hbudget.available()) {
    add('/api/hh/budget', {
      auth: 'household', methods: ['GET', 'POST'],
      async handler(req, res, _ctx, access) {
        const u = access.hhUser;
        const key = u.budget_profile_key || 'owner';
        try {
          if (req.method === 'GET') {
            const month = new URL(req.url || '/', 'http://localhost').searchParams.get('month');
            send(res, 200, await hbudget.getMonth(key, month, u.tz), nostore);
            return;
          }

          const body = await readJson(req, 64_000);
          const action = str(body?.action, 40);

          if (action === 'addRow') {
            const row = await hbudget.addRow(key, {
              date: body?.date, label: body?.label, bank: body?.bank,
              amount: body?.amount, kind: body?.kind,
            });
            send(res, 200, { ok: true, row }, nostore); return;
          }
          if (action === 'markBillPaid') {
            const out = await hbudget.markBillPaid(key, {
              tag: body?.tag, date: body?.date, label: body?.label,
              bank: body?.bank, amount: body?.amount,
            });
            send(res, 200, { ok: true, ...out }, nostore); return;
          }
          if (action === 'updateRow') {
            await hbudget.updateRow(key, Number(body?.id), {
              date: body?.date, label: body?.label, bank: body?.bank, amount: body?.amount,
            });
            send(res, 200, { ok: true }, nostore); return;
          }
          if (action === 'deleteRow') {
            await hbudget.deleteRow(key, Number(body?.id));
            send(res, 200, { ok: true }, nostore); return;
          }
          if (action === 'setDailyBalance') {
            const row = await hbudget.setDailyBalance(key, {
              day: body?.day, coastal: body?.coastal, truist: body?.truist, secu: body?.secu,
            });
            send(res, 200, { ok: true, dailyBalance: row }, nostore); return;
          }
          if (action === 'setCategory') {
            await hbudget.setRowCategory(key, Number(body?.id), body?.categoryId);
            send(res, 200, { ok: true }, nostore); return;
          }

          send(res, 400, { error: `Unknown action: ${action}` }, nostore);
        } catch (err) {
          // These throw human-readable messages ("Pick a date.", "Give it a
          // name.") — surfaced as 400s so the phone can show them verbatim
          // instead of a generic failure.
          send(res, 400, { error: String(err?.message || err) }, nostore);
        }
      },
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Today — one round trip for the whole screen
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // Composed server-side on purpose. The alternative is the phone firing five
  // requests over a mobile connection and painting the screen in five stages;
  // this way it paints once. Every query below is scoped by VISIBLE.
  add('/api/hh/today', {
    auth: 'household', methods: ['GET'],
    async handler(req, res, _ctx, access) {
      const me = access.hhUser.id;
      const p = hh.pool();
      try {
        const settings = await hh.getSettings(me);
        const slippingDays = Number(settings.slippingDays) || 7;
        const today = todayIn(access.hhUser.tz);

        const [top3, open, slipping, counts, people] = await Promise.all([
          // Top 3 — starred and open. Capped at 3 by design: a "top 3" of nine
          // items is just a list.
          p.query(
            `SELECT ${TASK_COLS} FROM hh_tasks
              WHERE ${VISIBLE} AND done_at IS NULL AND starred = TRUE
              ${OPEN_ORDER} LIMIT 3`, [me]),
          p.query(
            `SELECT ${TASK_COLS} FROM hh_tasks
              WHERE ${VISIBLE} AND done_at IS NULL ${OPEN_ORDER} LIMIT 200`, [me]),
          // Slipping — open, untouched for N days. Starred items are excluded:
          // they're already at the top of the screen, so flagging them again is
          // noise, not a nudge.
          p.query(
            `SELECT ${TASK_COLS} FROM hh_tasks
              WHERE ${VISIBLE} AND done_at IS NULL AND starred = FALSE
                AND touched_at < now() - ($2::int * interval '1 day')
              ORDER BY touched_at ASC LIMIT 10`, [me, slippingDays]),
          p.query(
            `SELECT
               COUNT(*) FILTER (WHERE done_at IS NULL)::int AS open,
               COUNT(*) FILTER (WHERE done_at IS NULL AND due_date < $2::date)::int AS overdue,
               COUNT(*) FILTER (WHERE done_at IS NULL AND due_date = $2::date)::int AS due_today,
               COUNT(*) FILTER (WHERE done_at >= date_trunc('day', now()))::int AS done_today
             FROM hh_tasks WHERE ${VISIBLE}`, [me, today]),
          // Both household members, so the UI can label a shared row with whose
          // it is without a lookup per row.
          hh.listUsers(),
        ]);

        // Resurfacing — one saved note, rotating daily. Chosen by day-number
        // modulo the pool size rather than at random, so it stays stable if you
        // reload the screen ten times in a morning, and still moves tomorrow.
        let resurfacing = null;
        const { rows: noteRows } = await p.query(
          `SELECT id, owner_id, kind, body, created_at FROM hh_notes
            WHERE ${VISIBLE} ORDER BY id ASC`, [me]);
        if (noteRows.length) {
          const dayNum = Math.floor(new Date(`${today}T00:00:00Z`).getTime() / 86_400_000);
          resurfacing = noteRows[dayNum % noteRows.length];
          p.query(`UPDATE hh_notes SET last_surfaced_at=now() WHERE id=$1`, [resurfacing.id])
            .catch(() => { /* cosmetic; never fail the screen over it */ });
        }

        send(res, 200, {
          today,
          tz: access.hhUser.tz,
          slippingDays,
          top3: top3.rows,
          open: open.rows,
          slipping: slipping.rows,
          counts: counts.rows[0] || { open: 0, overdue: 0, due_today: 0, done_today: 0 },
          resurfacing,
          people: people.map((u) => ({ id: u.id, displayName: u.display_name })),
          // Whether to show a Connect button or fetch events. The events
          // themselves come from /api/hh/calendar/events so a slow Google call
          // never delays this response.
          calendar: gcal
            ? await gcal.status(access.hhUser.id).catch(() => ({ configured: false, connected: false }))
            : { configured: false, connected: false },
          // Balances + what's due next, from the same budget tables. Wrapped
          // so a budget hiccup degrades one card instead of the whole screen.
          lists: hlists && hlists.available()
            ? await hlists.summary(access.hhUser.id, access.hhUser.tz).catch(() => null)
            : null,
          routines: hroutines && hroutines.available()
            ? await hroutines.summary(access.hhUser.id, access.hhUser.tz).catch(() => null)
            : null,
          money: hbudget && hbudget.available()
            ? await hbudget.summary(access.hhUser.budget_profile_key || 'owner', access.hhUser.tz)
                .catch(() => null)
            : null,
        }, nostore);
      } catch (err) { send(res, 500, { error: String(err?.message || err) }, nostore); }
    },
  });

  return n;
}

module.exports = { registerHouseholdRoutes };
