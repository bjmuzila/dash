import { useEffect, useRef, useState } from "react";
import RadialNav from "./RadialNav";
import RadialData from "./RadialData";

declare global {
  interface Window {
    mermaid?: any;
  }
}

// ─── Data flow (page → upstream sources) ────────────────────────────────────────
const DATA_GRAPH = `
flowchart LR
  WS["WS ws-gex"]
  INS["api insights"]
  GEXA["api gex chains"]
  SNAP["api snapshots"]
  LVL["api levels em"]
  CONF["api confidence"]
  ESA["api es-stats dxlink"]
  CAL["api calendars"]
  BUD["api budget"]
  DB["api db"]
  PROXY["proxy metrics"]
  HOME["home"]
  MG["mult-greek"]
  OC["options-chain"]
  GR["greeks"]
  CS["confidence-score"]
  EM["em"]
  ESC["es-candles"]
  FA["fails"]
  PM["premarket"]
  EC["economic-calendar"]
  BU["budget"]
  TR["trading"]
  DBP["database"]
  OWN["dev-owner"]

  HOME --> WS
  HOME --> INS
  HOME --> LVL
  MG --> GEXA
  MG --> SNAP
  OC --> GEXA
  GR --> INS
  GR --> SNAP
  CS --> CONF
  CS --> SNAP
  EM --> LVL
  ESC --> WS
  ESC --> ESA
  FA --> ESA
  PM --> GEXA
  EC --> CAL
  BU --> BUD
  TR --> SNAP
  DBP --> DB
  OWN --> PROXY

  classDef pg fill:#0b1626,stroke:#22d3ee,color:#cfe0ee;
  classDef api fill:#10231b,stroke:#34d399,color:#a7f3d0;
  classDef ws fill:#231016,stroke:#fb7185,color:#fecdd3;
  class HOME,MG,OC,GR,CS,EM,ESC,FA,PM,EC,BU,TR,DBP,OWN pg;
  class INS,GEXA,SNAP,LVL,CONF,ESA,CAL,BUD,DB,PROXY api;
  class WS ws;
`;

export default function FlowDiagram() {
  const [mode, setMode] = useState<"nav" | "data">("nav");
  const [zoom, setZoom] = useState(1);
  const [fit, setFit] = useState(true);
  const [ready, setReady] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // load mermaid from CDN once
  useEffect(() => {
    if (window.mermaid) {
      setReady(true);
      return;
    }
    const s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.min.js";
    s.onload = () => {
      window.mermaid.initialize({
        startOnLoad: false,
        theme: "dark",
        securityLevel: "loose",
        themeVariables: { fontSize: "22px" },
        flowchart: { nodeSpacing: 55, rankSpacing: 70, padding: 16, useMaxWidth: false },
      });
      setReady(true);
    };
    document.body.appendChild(s);
  }, []);

  // (re)render on mode change — only Data Flow uses mermaid; nav uses RadialNav
  useEffect(() => {
    if (mode === "nav") return;
    if (!ready || !ref.current || !window.mermaid) return;
    const src = DATA_GRAPH;
    ref.current.innerHTML = "";
    const id = "tree-mmd-" + Date.now();
    window.mermaid
      .render(id, src)
      .then(({ svg }: { svg: string }) => {
        if (!ref.current) return;
        // strip mermaid's sizing caps so we control scale ourselves
        svg = svg
          .replace(/max-width:\s*[\d.]+px;?/g, "")
          .replace(/style="[^"]*"/, "")
          .replace(/width="[^"]*"/, "")
          .replace(/height="[^"]*"/, "");
        ref.current.innerHTML = svg;
        applyZoom();
      })
      .catch((e: unknown) => {
        if (ref.current) ref.current.innerHTML = `<pre style="color:#EF4444">${String(e)}</pre>`;
      });
  }, [ready, mode]);

  function applyZoom() {
    const svg = ref.current?.querySelector("svg") as SVGSVGElement | null;
    if (!svg || !ref.current) return;
    svg.style.maxWidth = "none";
    if (fit) {
      // scale to fill the container width
      svg.style.width = "100%";
      svg.style.height = "auto";
    } else {
      const vb = svg.viewBox.baseVal;
      const baseW = vb && vb.width ? vb.width : 1200;
      const baseH = vb && vb.height ? vb.height : 800;
      svg.style.width = baseW * zoom + "px";
      svg.style.height = baseH * zoom + "px";
    }
  }

  // re-apply zoom when slider moves
  useEffect(() => {
    applyZoom();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [zoom, fit]);

  const btn = (m: "nav" | "data", label: string) => (
    <button
      onClick={() => setMode(m)}
      style={{
        padding: "7px 16px", borderRadius: 8, fontSize: 15, fontWeight: 600, cursor: "pointer",
        border: `1px solid ${mode === m ? "#22d3ee" : "rgba(255,255,255,0.12)"}`,
        background: mode === m ? "rgba(34,211,238,0.12)" : "transparent",
        color: mode === m ? "#22d3ee" : "rgba(255,255,255,0.55)",
      }}
    >
      {label}
    </button>
  );

  return (
    <div>
      <div style={{ display: "flex", gap: 6, marginBottom: 16, alignItems: "center", flexWrap: "wrap" }}>
        {btn("nav", "Navigation Flow")}
        {btn("data", "Data Flow")}
        <div style={{ display: "none", alignItems: "center", gap: 8, marginLeft: "auto" }}>
          <button onClick={() => setFit(true)}
            style={{ padding: "6px 12px", borderRadius: 8, fontSize: 15, fontWeight: 600, cursor: "pointer",
              border: `1px solid ${fit ? "#22d3ee" : "rgba(255,255,255,0.12)"}`,
              background: fit ? "rgba(34,211,238,0.12)" : "transparent",
              color: fit ? "#22d3ee" : "rgba(255,255,255,0.55)" }}>Fit</button>
          <button onClick={() => { setFit(false); setZoom((z) => Math.max(0.6, +(z - 0.2).toFixed(2))); }}
            style={{ width: 30, height: 30, borderRadius: 8, border: "1px solid rgba(255,255,255,0.12)", background: "transparent", color: "#9fc", fontSize: 16, cursor: "pointer" }}>−</button>
          <input type="range" min={0.6} max={3} step={0.1} value={zoom}
            onChange={(e) => { setFit(false); setZoom(+e.target.value); }} style={{ width: 140 }} />
          <button onClick={() => { setFit(false); setZoom((z) => Math.min(3, +(z + 0.2).toFixed(2))); }}
            style={{ width: 30, height: 30, borderRadius: 8, border: "1px solid rgba(255,255,255,0.12)", background: "transparent", color: "#9fc", fontSize: 16, cursor: "pointer" }}>+</button>
          <span style={{ color: "rgba(255,255,255,0.5)", fontSize: 15, width: 38 }}>{fit ? "fit" : Math.round(zoom * 100) + "%"}</span>
        </div>
      </div>
      <div
        style={{
          background: "rgba(255,255,255,0.02)",
          border: "1px solid rgba(255,255,255,0.10)",
          borderRadius: 14,
          padding: 18,
          height: "82vh",
          overflow: "hidden",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {mode === "nav" ? <RadialNav /> : <RadialData />}
      </div>
    </div>
  );
}
