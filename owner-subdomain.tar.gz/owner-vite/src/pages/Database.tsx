import { useState, useEffect, useCallback } from "react";
import { useRefreshButton } from "../hooks/useRefreshButton";
import {
  HOME_THEME,
  homeButtonStyle,
  homeContentStyle,
  homeHeaderStyle,
  homeInputStyle,
  homePanelStyle,
  homeSecondaryButtonStyle,
  homeShellStyle,
} from "../lib/theme";
import { DockCalendar } from "../components/DockToolbar";

// Friendly labels for the tables we already know about. Any table not listed
// here (including new ones added later) still shows up — just titlecased from
// its raw name — because the picker is now driven by /api/db/tables, which
// reads information_schema, not this array.
const KNOWN_LABELS: Record<string, string> = {
  eod_gex: "EOD GEX",
  mvc_snapshots: "CB - Core Bullseye Snapshots",
  premium_flow: "Premium Flow",
  greeks_ts: "Greeks TS",
  playbook_feed: "Playbook Feed",
  page_load_status: "Page Status",
  es_candles: "ES Candles",
  bzila_snapshots: "Bzila Snaps",
  flow_calls: "Flow Calls",
  snapshots: "EM Snapshots",
  ticker_levels: "Levels (/em)",
  es_stats: "ES Stats",
  trades: "Trades",
  expirations_cache: "Exp Cache",
};

function labelFor(table: string): string {
  return KNOWN_LABELS[table] ?? table.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

// The small "today" summary widgets below only track this curated subset —
// the main table browser (DatabasePage) is the part that covers every table.
const CURATED_TABLES = [
  "eod_gex", "mvc_snapshots", "premium_flow", "greeks_ts", "playbook_feed",
  "page_load_status", "es_candles", "bzila_snapshots", "flow_calls",
  "snapshots", "ticker_levels", "es_stats", "trades", "expirations_cache",
] as const;

type TableId = string;

function fmtCell(v: unknown, key?: string): string {
  if (v == null) return "-";
  if (typeof v === "number") {
    if (!Number.isFinite(v)) return "-";
    if (
      key === "esPrice" ||
      key === "spxPrice" ||
      key === "price" ||
      key === "underlying" ||
      key === "open" ||
      key === "high" ||
      key === "low" ||
      key === "close" ||
      key === "spot"
    ) {
      return v.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    }
    if (key === "ts" || key?.includes("time")) {
      const d = new Date(v);
      if (!isNaN(d.getTime())) {
        return d.toLocaleTimeString("en-US", {
          hour12: false,
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        });
      }
    }
    return Number.isInteger(v) ? v.toString() : v.toFixed(4);
  }
  if (typeof v === "object") {
    const s = JSON.stringify(v);
    return s.length > 60 ? s.slice(0, 60) + "..." : s;
  }
  const s = String(v);
  if (/^\d{13}$/.test(s)) {
    const d = new Date(Number(s));
    return d.toLocaleTimeString("en-US", {
      hour12: false,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  }
  return s.length > 80 ? s.slice(0, 80) + "..." : s;
}

function fmtStrikeCell(v: unknown): string {
  if (v == null) return "-";
  if (typeof v === "number") {
    return Number.isInteger(v)
      ? v.toLocaleString("en-US")
      : v.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  }
  const n = Number(String(v).replace(/,/g, ""));
  if (!Number.isFinite(n)) return String(v);
  return Number.isInteger(n)
    ? n.toLocaleString("en-US")
    : n.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

function todayET() {
  return new Date(new Date().toLocaleString("en-US", { timeZone: "America/New_York" }))
    .toISOString()
    .slice(0, 10);
}

/** Compact GEX formatter: +$1.23B / -$45.6M / +$789K. */
function fmtGex(v: number): string {
  const abs = Math.abs(v);
  const sign = v >= 0 ? "+" : "-";
  if (abs >= 1e9) return `${sign}$${(abs / 1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `${sign}$${(abs / 1e6).toFixed(2)}M`;
  return `${sign}$${(abs / 1e3).toFixed(2)}K`;
}

interface EodGexRow { symbol: string; total_gex: number; spot: number; computed_at: string }

/**
 * EOD GEX save status for today ($SPX/SPY/QQQ). Moved here from the owner
 * dashboard so all DB surfaces live on the backend Database page. The recorder
 * fires 3:55–4:05 PM ET; before that this shows "not yet recorded".
 */
function EodGexToday() {
  const [rows, setRows] = useState<EodGexRow[]>([]);
  const [loading, setLoading] = useState(true);

  const loadEod = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch(`/api/eod-gex?date=${todayET()}`, { cache: "no-store" });
      if (r.ok) { const j = await r.json(); setRows((j.rows ?? []) as EodGexRow[]); }
    } catch { /* non-fatal */ }
    setLoading(false);
  }, []);

  useEffect(() => { void loadEod(); }, [loadEod]);

  return (
    <div style={{ ...homePanelStyle, padding: "14px 16px", marginBottom: 12 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
        <span style={{ fontSize: 14, fontWeight: 700, color: HOME_THEME.text, letterSpacing: "0.01em" }}>EOD GEX · Today</span>
        <span style={{ fontSize: 12, color: HOME_THEME.muted, fontFamily: "var(--font-mono)" }}>
          {loading ? "loading…" : rows.length === 0 ? "not yet recorded" : `${rows.length} symbol(s) saved`}
        </span>
      </div>
      {rows.length === 0 && !loading ? (
        <div style={{ fontSize: 12, color: HOME_THEME.muted, fontFamily: "var(--font-mono)" }}>
          Not yet recorded today — fires 3:55–4:05 PM ET
        </div>
      ) : (
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          {(["$SPX", "SPY", "QQQ"] as const).map((sym) => {
            const row = rows.find((r) => r.symbol === sym);
            const ok = !!row;
            const tStr = row?.computed_at
              ? new Date(row.computed_at).toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit", timeZone: "America/New_York" }) + " ET"
              : null;
            return (
              <div key={sym} style={{
                ...homePanelStyle, padding: "12px 16px", display: "flex", flexDirection: "column", gap: 4,
                borderLeft: `3px solid ${ok ? HOME_THEME.green : HOME_THEME.red}55`,
                background: `linear-gradient(135deg, ${ok ? HOME_THEME.green : HOME_THEME.red}14 0%, transparent 100%)`,
                minWidth: 160,
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <span style={{ width: 7, height: 7, borderRadius: "50%", flexShrink: 0, background: ok ? HOME_THEME.green : HOME_THEME.red, boxShadow: `0 0 6px ${ok ? HOME_THEME.green : HOME_THEME.red}` }} />
                  <span style={{ fontSize: 12, fontWeight: 500, color: ok ? HOME_THEME.green : HOME_THEME.red, letterSpacing: "0.1em" }}>{sym}</span>
                </div>
                {row ? (
                  <>
                    <div style={{ fontSize: 18, fontWeight: 500, fontFamily: "var(--font-mono)", color: HOME_THEME.text }}>{fmtGex(row.total_gex)}</div>
                    <div style={{ fontSize: 12, fontFamily: "var(--font-mono)", color: HOME_THEME.text, opacity: 0.9 }}>
                      spot {row.spot.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                    {tStr && <div style={{ fontSize: 9, color: `${HOME_THEME.green}88` }}>{tStr}</div>}
                  </>
                ) : (
                  <div style={{ fontSize: 12, color: HOME_THEME.red, fontFamily: "var(--font-mono)" }}>not saved</div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default function Database() {
  const [tab, setTab] = useState<TableId>("eod_gex");
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [cols, setCols] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [count, setCount] = useState(0);
  const [dateFilter, setDateFilter] = useState<string>(todayET());
  const [limit, setLimit] = useState(200);
  const [allTables, setAllTables] = useState<{ name: string; approx_rows: number; today_rows?: number | null }[]>([]);
  const [tableSearch, setTableSearch] = useState("");

  // Every base table in the DB, fetched once from information_schema (via
  // /api/db/tables) — this is what makes the picker cover EVERYTHING being
  // saved, not just the curated 14 this page originally shipped with.
  // `today=` also returns today's row count per table, which replaces the old
  // "Database · Today" card grid: the count now lives in the table button.
  useEffect(() => {
    fetch(`/api/db/tables?today=${todayET()}`, { cache: "no-store" })
      .then((r) => r.json())
      .then((j) => setAllTables(Array.isArray(j.tables) ? j.tables : []))
      .catch(() => setAllTables([]));
  }, []);

  const load = useCallback(async (t: TableId, date: string, lim: number) => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ table: t, limit: String(lim) });
      if (date) params.set("date", date);
      const res = await fetch(`/api/db?${params.toString()}`, { cache: "no-store" });
      const json = await res.json();
      if (!res.ok) throw new Error(json.detail || json.error || `HTTP ${res.status}`);
      const fetched = (json.rows ?? []) as Record<string, unknown>[];
      setRows(fetched);
      setCount(json.count ?? fetched.length);
      setCols(fetched.length ? Object.keys(fetched[0]) : []);
    } catch (e) {
      setError(String(e));
      setRows([]);
      setCount(0);
      setCols([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const { trigger: refreshTrigger, label: refreshLabel, style: refreshStyle } =
    useRefreshButton(useCallback(async () => {
      await load(tab, dateFilter, limit);
    }, [load, tab, dateFilter, limit]));

  useEffect(() => {
    void load(tab, dateFilter, limit);
  }, [tab, dateFilter, limit, load]);

  useEffect(() => {
    const handler = () => void load(tab, dateFilter, limit);
    window.addEventListener("db-mvc-updated", handler);
    return () => window.removeEventListener("db-mvc-updated", handler);
  }, [tab, dateFilter, limit, load]);

  return (
    <div style={homeShellStyle}>
      <div style={homeHeaderStyle}>
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-xs font-bold uppercase tracking-widest" style={{ color: HOME_THEME.cyan }}>
            Database
          </span>
          <span className="text-xs font-mono" style={{ color: HOME_THEME.muted }}>
            {loading ? "Loading..." : `${count} rows`}
          </span>
          <div className="flex items-center gap-1">
            <span className="text-xs" style={{ color: HOME_THEME.muted }}>Date:</span>
            <DockCalendar value={dateFilter} onChange={setDateFilter} />
            <button
              onClick={() => setDateFilter(todayET())}
              style={{ fontSize: 10, color: HOME_THEME.cyan, background: "transparent", border: "none", cursor: "pointer", padding: "2px 4px" }}
            >
              Today
            </button>
            <button
              onClick={() => setDateFilter("")}
              style={{ fontSize: 10, color: HOME_THEME.muted, background: "transparent", border: "none", cursor: "pointer", padding: "2px 4px" }}
            >
              All
            </button>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-xs" style={{ color: HOME_THEME.muted }}>Limit:</span>
            {[100, 200, 500].map((n) => (
              <button
                key={n}
                onClick={() => setLimit(n)}
                style={{
                  ...homeSecondaryButtonStyle,
                  fontSize: 10,
                  padding: "2px 7px",
                  borderRadius: 4,
                  borderColor: limit === n ? HOME_THEME.cyan : HOME_THEME.border,
                  color: limit === n ? HOME_THEME.cyan : HOME_THEME.muted,
                }}
              >
                {n}
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={refreshTrigger} style={{ ...homeButtonStyle, color: (refreshStyle.color as string) ?? (homeButtonStyle as { color?: string }).color }}>
            {refreshLabel}
          </button>
        </div>
      </div>

      <div style={{ ...homeContentStyle, display: "flex", flexDirection: "column", minHeight: 0, overflow: "hidden" }}>
        <EodGexToday />
        <div style={{ ...homePanelStyle, display: "flex", flexDirection: "column", flex: 1, minHeight: 0, overflow: "hidden" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: 8, borderBottom: `1px solid ${HOME_THEME.border}`, flexShrink: 0 }}>
            {/* Every base table in the DB (information_schema) — one push button each.
                Button shows (total rows)(rows written today, red). */}
            <div className="flex items-center gap-2 flex-wrap">
              <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: ".08em", textTransform: "uppercase", color: HOME_THEME.muted }}>
                Table ({allTables.length || "…"})
              </span>
              <input
                value={tableSearch}
                onChange={(e) => setTableSearch(e.target.value)}
                placeholder="filter…"
                style={{ ...homeInputStyle, width: 140, fontSize: 11, padding: "5px 8px" }}
              />
              <span style={{ fontSize: 10, color: HOME_THEME.muted }}>
                (total)<span style={{ color: HOME_THEME.red }}>(today)</span>
              </span>
            </div>
            {/* Capped + scrollable so ~84 buttons can't push the data grid off the page. */}
            <div className="flex flex-wrap" style={{ gap: 6, maxHeight: 168, overflowY: "auto", paddingRight: 4 }}>
              {(allTables.length ? allTables : CURATED_TABLES.map((n) => ({ name: n, approx_rows: 0, today_rows: null as number | null })))
                .filter((t) => t.name.toLowerCase().includes(tableSearch.toLowerCase()))
                .map((t) => {
                  const on = tab === t.name;
                  const today = t.today_rows;
                  return (
                    <button
                      key={t.name}
                      onClick={() => setTab(t.name)}
                      style={{
                        padding: "6px 12px",
                        fontSize: 11,
                        fontWeight: 700,
                        letterSpacing: ".08em",
                        textTransform: "uppercase",
                        borderRadius: 8,
                        border: on ? `1px solid ${HOME_THEME.cyan}59` : `1px solid ${HOME_THEME.border}`,
                        background: on
                          ? `linear-gradient(180deg, ${HOME_THEME.cyan}2e, ${HOME_THEME.cyan}0d)`
                          : "rgba(255,255,255,0.04)",
                        color: on ? HOME_THEME.cyan : HOME_THEME.text,
                        cursor: "pointer",
                        whiteSpace: "nowrap",
                        boxShadow: on ? `0 0 14px ${HOME_THEME.cyan}3a, 0 2px 8px rgba(0,0,0,0.35)` : "none",
                        transition: "background .14s, color .14s, border-color .14s",
                      }}
                      title={today != null ? `${t.approx_rows.toLocaleString()} total · ${today.toLocaleString()} today` : `${t.approx_rows.toLocaleString()} total`}
                    >
                      {labelFor(t.name)} ({t.approx_rows.toLocaleString()})
                      {today != null && today > 0 && (
                        <span style={{ color: HOME_THEME.red, marginLeft: 2 }}>({today.toLocaleString()})</span>
                      )}
                    </button>
                  );
                })}
            </div>
          </div>

          <div className="flex-1 overflow-auto">
            {error ? (
              <div className="flex flex-col items-center justify-center h-40 gap-2 text-xs" style={{ color: HOME_THEME.red }}>
                <div>{error}</div>
              </div>
            ) : loading ? (
              <div className="flex items-center justify-center h-40 text-xs" style={{ color: HOME_THEME.muted }}>Loading...</div>
            ) : cols.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-40 gap-1 text-xs" style={{ color: HOME_THEME.muted }}>
                <div>No data in <strong>{tab}</strong></div>
                {dateFilter && <div style={{ fontSize: 10 }}>Try clearing the date filter (All)</div>}
              </div>
            ) : (
              <table style={{ width: "100%", fontSize: 11, fontFamily: "var(--font-mono)", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ background: "rgba(13,17,25,0.88)", position: "sticky", top: 0, zIndex: 1, backdropFilter: "blur(16px)" }}>
                    {cols.map((c) => (
                      <th
                        key={c}
                        style={{
                          padding: "8px 10px",
                          textAlign: "left",
                          borderBottom: `1px solid ${HOME_THEME.border}`,
                          color: HOME_THEME.muted,
                          fontWeight: 700,
                          whiteSpace: "nowrap",
                          textTransform: "uppercase",
                          letterSpacing: "0.08em",
                          fontSize: 9,
                        }}
                      >
                        {c}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, i) => (
                    <tr
                      key={i}
                      style={{
                        borderBottom: `1px solid ${HOME_THEME.border}`,
                        background: i % 2 === 0 ? "transparent" : "rgba(255,255,255,.02)",
                      }}
                    >
                      {cols.map((c) => {
                        const v = row[c];
                        const isStrike = c.toLowerCase().includes("strike");
                        const n = typeof v === "number";
                        const neg = n && v < 0;
                        const pos = n && v > 0;
                        return (
                          <td
                            key={c}
                            style={{
                              padding: "6px 10px",
                              whiteSpace: "nowrap",
                              color: neg ? HOME_THEME.red : pos ? HOME_THEME.text : HOME_THEME.muted,
                              textAlign: n ? "right" : "left",
                              maxWidth: 220,
                              overflow: "hidden",
                              textOverflow: "ellipsis",
                            }}
                          >
                            {isStrike ? fmtStrikeCell(v) : fmtCell(v, c)}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
